clc;
clear;

% Loading the signal
x = load('speech_with_beeps.txt');
fs = 8000;
% sound(x,fs);

% Using Stft/spectrogram 
frame_size = 160;
overlap = frame_size / 2;
window = hamming(frame_size);
fft_size = 2^nextpow2(frame_size);

[X, f, t] = spectrogram(x, window, overlap, fft_size, fs);

% plotting the spectrogram
figure;
imagesc(t, f, 20*log10(abs(X)));
axis xy;
xlabel('Time (s)');
ylabel('Frequency (Hz)');
title('Spectrogram of the speech_with_beeps.txt');
colorbar;

% Finding the peaks in the given signal
row_indices = [];
col_indices = [];
max_val = [];
max_idx = [];

for col = 2:(size(X, 2) - 1)
    for n = 1:5
        [max_val(6), max_idx(6)] = max(X(:, col));
        if col+n <= length(t)
            [max_val(n), max_idx(n)] = max(X(:, col+n));
        end 
        if n < col
            [max_val(6+n), max_idx(6+n)] = max(X(:, col-n));
        end
    end 
    if allEqual(max_idx)
            row_indices = [row_indices; max_idx];
            col_indices = [col_indices; col];
    end
end

% Plot to show the identified peaks
figure;
imagesc(t, f, 20*log10(abs(X)));
axis xy;
hold on;
scatter(t(col_indices), f(row_indices), 'r', 'filled');
hold off;
xlabel('Time (s)');
ylabel('Frequency (Hz)');
title('Spectrogram with Identified Local Peaks');
colorbar;

% Finding unique frequencies and thier corresponding colomn indices
freq_colomn_ranges = [];

for i = 1:length(row_indices)
    freq = f(row_indices(i)); 
    start_col = col_indices(i); 
    if i < length(row_indices)
        end_col = col_indices(i+1) - 1;
    else
        end_col = size(X, 2);
    end
    freq_colomn_ranges = [freq_colomn_ranges; freq, start_col, end_col];
end

% disp(freq_colomn_ranges)

unique_freq = unique(freq_colomn_ranges(:,1));
min_start_col = zeros(size(unique_freq));
max_end_col = zeros(size(unique_freq));

for i = 1:length(unique_freq)
    freq = unique_freq(i);
    indices = find(freq_colomn_ranges(:,1) == freq);
    min_start_col(i) = min(freq_colomn_ranges(indices,2));
    max_end_col(i) = max(freq_colomn_ranges(indices,3));
end
% disp('Unique Frequencies, Min Start Column, Max End Column:');
% result = [unique_freq, min_start_col, max_end_col];
% disp(result);

% Applying notch filter for each frequency on thier corresponding colomn indice range 
for i = 1:length(unique_freq)
    freq = unique_freq(i);
    start_col = min_start_col(i);
    end_col = max_end_col(i);
    start_index = round(t(start_col-10) * fs); % Due to our algorithm we will miss the first and last 4 samples of the beep signal. So we add them and also an extra 5 samples each side to be safe.
    if end_col+10 < length(t)
        end_index = round(t(end_col+10) * fs);
    else 
        end_index = round(t(end_col) * fs);
    end
    x_filtered_interval = x(start_index:end_index);
    peak_freq = freq;
    normalized_peak_freq = peak_freq / (fs/2); 
    Q = 30; % Quality factor can be changed based on the signal for better results 
    bw = normalized_peak_freq / Q; 
    [b, a] = iirnotch(normalized_peak_freq, bw);
    filter_order = 10; %  Order of the filter can be changed based on the signal for better results 
    for i = 1: filter_order
        x_filtered_interval = filter(b, a, x_filtered_interval); 
    end 
    x(start_index:end_index) = x_filtered_interval;
end

% Save the audio file as audio.wav
sound(x, fs); 
filename = 'audio.wav';
audiowrite(filename, x, fs); 
disp(['Filtered audio saved as ', filename]);

[X_filtered, f_filtered, t_filtered] = spectrogram(x, window, overlap, fft_size, fs);
figure;
imagesc(t_filtered, f_filtered, 20*log10(abs(X_filtered)));
axis xy;
xlabel('Time (s)');
ylabel('Frequency (Hz)');
title('Spectrogram with Highlighted Peaks Nullified');
colorbar;

function y = allEqual(arr) 
    y = numel(unique(arr)) == 1;
end
