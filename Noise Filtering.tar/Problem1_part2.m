clc;
clear;
x = load('speech_noisy.txt');

fs = 8000;
% sound(x,fs);

% Using Stft/spectrogram 
frame_size = 160;
overlap = frame_size / 2;
window = hamming(frame_size);
fft_size = 2^nextpow2(frame_size);

[X, f, t] = spectrogram(x, window, overlap, fft_size, fs);

threshold_dB = 0;
X_dB = 20*log10(abs(X));

% Using a for loop to run through frequency colomn and find the frequency band where for a given freqency, 30% of the time the signal's amplitude is > 0.
num_frames = size(X, 2);

threshold_count = ceil(0.30 * num_frames);
highlighted_freq = zeros(size(X, 1), 1);

for freq_bin = 1:size(X, 1)
    count = sum(X_dB(freq_bin, :) > threshold_dB);
    if count >= threshold_count
        highlighted_freq(freq_bin) = 1;
    end
end
highlighted_freq_indices = find(highlighted_freq);
highlighted_freq_values = f(highlighted_freq_indices);
max_highlighted_freq = max(highlighted_freq_values);
min_highlighted_freq = min(highlighted_freq_values);

disp(['Maximum Highlighted Frequency: ', num2str(max_highlighted_freq), ' Hz']);
disp(['Minimum Highlighted Frequency: ', num2str(min_highlighted_freq), ' Hz']);

% Normamlizing frequency and applying a stop band for the identified stop band
stopband_freq = [min_highlighted_freq - 100 , max_highlighted_freq + 100];

[num, den] = ellip(6, 0.1, 60, [stopband_freq(1), stopband_freq(2)]/(fs/2), 'stop');
x_filtered = filter(num, den, x);
[X_filtered, f_filtered, t_filtered] = spectrogram(x_filtered, window, overlap, fft_size, fs);

%plotting the original signal and the filtered signal 
figure;
imagesc(t_filtered, f_filtered, 20*log10(abs(X_filtered)));
axis xy;
xlabel('Time (s)');
ylabel('Frequency (Hz)');
title('Filtered Spectrogram');
colorbar;
sound(x_filtered, fs);
figure;
imagesc(t, f, X_dB);
axis xy;
xlabel('Time (s)');
ylabel('Frequency (Hz)');
title('Spectrogram with Highlighted Peaks Nullified');
hold on;
highlighted_freq_indices = find(highlighted_freq);
for i = 1:length(highlighted_freq_indices)
    plot([min(t), max(t)], [f(highlighted_freq_indices(i)), f(highlighted_freq_indices(i))], 'r--', 'LineWidth', 1.5);
end
colorbar;




